using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace vehiclecrash.Views.Home
{
    public class ViewSingleModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
