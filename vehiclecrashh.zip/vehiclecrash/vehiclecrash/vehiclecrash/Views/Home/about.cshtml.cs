using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace vehiclecrash.Views.Home
{
    public class aboutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
