using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace vehiclecrash.Views.Home
{
    public class graphModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
